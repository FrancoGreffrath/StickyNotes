
# Sticky Notes (Django)

A minimal CRUD web app for sticky notes built with Django. It implements Model–View–Template architecture, forms, URL routing, templates, and static files.

## Quick start
1. Create & activate a virtual environment.
2. Install dependencies: `pip install -r requirements.txt`.
3. Run migrations: `python manage.py makemigrations` then `python manage.py migrate`.
4. Start dev server: `python manage.py runserver`.
5. Visit http://127.0.0.1:8000 to use the app.

## Project structure
```
sticky_notes/
  manage.py
  sticky_notes/ (project)
  notes/ (app)
  docs/ (UML & research)
```

## Academic integrity
Please personalise the code comments, variable names, and the research write‑up to reflect your own understanding before submitting.


## Testing

### Unit Testing
Unit tests were implemented using Django's TestCase framework.  
Tests cover:
- Note creation (model test)
- Viewing note list
- Viewing note detail
- Deleting notes

Run tests using:
```
python manage.py test
```

### Manual Testing
The application was manually tested through the browser:
- Created new notes
- Updated notes
- Deleted notes
- Verified persistence after refresh
- No critical bugs found

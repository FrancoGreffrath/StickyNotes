
from django.db import models

class Note(models.Model):
    """A sticky note entity representing minimal text content.
    Fields:
        title: brief title of the note
        content: the body text of the note
        created_at: timestamp when created
        updated_at: timestamp when last edited
    """
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self) -> str:
        return self.title

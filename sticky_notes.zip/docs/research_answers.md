
# research_answers

## 1) How HTTP apps preserve state (sessions & auth)
Web apps are stateless by default, so Django uses a session ID stored in a cookie to link the browser to server‑side session data. The `SessionMiddleware` reads/writes this cookie and Django stores the session data (by default) in the database. Authentication builds on sessions: after a successful login, Django associates the user with the session so subsequent requests are recognised.

## 2) Migrating Django from SQLite to a server DB like MariaDB
Use the MariaDB/MySQL backend (`ENGINE = 'django.db.backends.mysql'`) and install a compatible client (e.g. `mysqlclient`). Create a database and credentials in MariaDB, then update `settings.py` with NAME/USER/PASSWORD/HOST/PORT. Finally, run `makemigrations` then `migrate` to apply your models onto MariaDB.

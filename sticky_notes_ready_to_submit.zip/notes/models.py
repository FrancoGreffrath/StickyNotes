from django.db import models

class Note(models.Model):
    # Title of the note displayed in lists and detail pages
    title = models.CharField(max_length=100)

    # Main body text of the note
    content = models.TextField()

    # Timestamp automatically set when note is created
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        # String representation used in admin and debugging
        return self.title

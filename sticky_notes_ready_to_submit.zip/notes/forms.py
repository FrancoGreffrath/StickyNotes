
from django import forms
from .models import Note

class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'content']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'input', 'placeholder': 'Note title'}),
            'content': forms.Textarea(attrs={'class': 'textarea', 'rows': 6, 'placeholder': 'Write your note here...'}),
        }
